package config.annotations;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Entrenamientos {

    @Value("${Entrenamiento1}")
    private String entrenamiento1;

    @Value("${Entrenamiento2}")
    private String entrenamiento2;

    @Value("${Entrenamiento3}")
    private String entrenamiento3;

    @Value("${Entrenamiento4}")
    private String entrenamiento4;

    public String getEntrenamiento1() {
        return entrenamiento1;
    }

    public String getEntrenamiento2() {
        return entrenamiento2;
    }

    public String getEntrenamiento3() {
        return entrenamiento3;
    }

    public String getEntrenamiento4() {
        return entrenamiento4;
    }
}