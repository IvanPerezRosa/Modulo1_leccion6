package config.annotations;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Principal {

    public static void main(String[] args) {

        AnnotationConfigApplicationContext contexto = new AnnotationConfigApplicationContext(Config.class);

        Jugador Joaquin = contexto.getBean("capitan", Jugador.class);
        Entrenamientos entrenamientos = contexto.getBean(Entrenamientos.class);

        System.out.println("Entrenamientos de " + Joaquin.getNombre() + ":");
        System.out.println("Primer Entrenamiento: " + entrenamientos.getEntrenamiento1());
        System.out.println("Segundo Entrenamiento: " + entrenamientos.getEntrenamiento2());
        System.out.println("Tercer Entrenamiento: " + entrenamientos.getEntrenamiento3());
        System.out.println("Cuarto Entrenamiento: " + entrenamientos.getEntrenamiento4());

        contexto.close();
    }
}