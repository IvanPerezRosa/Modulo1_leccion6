package config.annotations;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan("config.annotations")
@PropertySource("classpath:atributos.properties")
public class Config {

}