package config.annotations;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("capitan")
public class Jugador {

    @Value("${Capitan}")
    private String nombre;

    public String getNombre() {
        return nombre;
    }
}