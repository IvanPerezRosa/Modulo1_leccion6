package config.annotations;

public interface Jugadores {

	public String getNombre();

	public String getEntrenamiento1();
	
	public String getEntrenamiento2();

	public String getEntrenamiento3();

	public String getEntrenamiento4();

	
}
